## To-Do List for Heuristic Labeling and Presentation Project

### Phase 1: Desenvolver critérios heurísticos e sistema de rotulagem
- [x] Definir critérios heurísticos para "original" (lojas oficiais, preço médio, verificado, etc.).
- [x] Definir critérios heurísticos para "suspeito/pirata" (preço baixo, loja desconhecida, erros gramaticais, etc.).
- [x] Implementar uma função em Python para aplicar esses critérios e rotular os dados.
- [x] Testar a função de rotulagem com os dados existentes.

### Phase 2: Gerar dataset estruturado com features e rótulos
- [x] Selecionar as features relevantes para o dataset final.
- [x] Aplicar a função de rotulagem para criar a feature target (original/pirata).
- [x] Salvar o dataset estruturado em formato CSV.

### Phase 3: Preparar apresentação documentando o processo
- [x] Criar a estrutura da apresentação (slides).
- [x] Documentar as fontes de dados e o processo de scraping.
- [x] Detalhar os critérios heurísticos de rotulagem e as decisões tomadas.
- [x] Descrever as features coletadas.
- [x] Incluir 5 exemplos de amostras de dados (com rótulos).
- [x] Gerar a apresentação em formato PDF.

### Phase 4: Finalizar entregáveis e documentação
- [ ] Revisar todos os arquivos gerados (dataset CSV, apresentação PDF).
- [ ] Criar um arquivo ZIP com todos os entregáveis.
- [ ] Atualizar o README com instruções (se necessário).


