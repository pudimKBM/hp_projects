## To-Do List for Web Scraping Project - Entregável 2

### Phase 1: Analisar as novas demandas do Entregável 2
- [x] Read and understand the new project requirements from `pasted_content.txt`.

### Phase 2: Limpeza e Padronização dos Dados
- [x] Correct fields with symbols, line breaks, excess spaces, and encoding errors.
- [x] Normalize formats for prices, names, descriptions, and technical terms.
- [x] Handle missing data and duplicate records.

### Phase 3: Enriquecimento dos Dados com Colunas Derivadas
- [x] Create new variables based on existing data.
- [x] Implement automated classification (e.g., original, compatible, suspicious) based on keywords.
- [x] Extract technical attributes from descriptions using regular expressions.
- [x] Create binary reliability indicators (e.g., presence of “sealed”, “invoice”, “warranty”).

### Phase 4: Análise Exploratória de Dados (EDA)
- [x] Apply exploratory data analysis techniques to identify patterns and anomalies.
- [x] Perform descriptive statistics on price, sellers, and product types.
- [x] Identify outliers and abnormal behaviors.
- [x] Explore descriptions lexically through term frequency.

### Phase 5: Identificação e Coleta de Dados de Nova Fonte
- [ ] Identify at least one additional data source (e.g., other e-commerce platforms, official HP catalogs, public APIs, open datasets).
- [ ] Justify the choice of the new data source.
- [ ] Implement data extraction strategy for the new source.
- [ ] Document challenges encountered and solutions applied.

### Phase 6: Integração e Consolidação dos Dados
- [x] Standardize and merge data from the new source with the main database.
- [x] Consolidate all data into a single, enriched base.

### Phase 7: Documentação e Geração de Relatório Técnico
- [x] Prepare the technical report in PDF format.
- [x] Describe the data treatment process.
- [x] Explain the creation of derived columns.
- [x] Detail the new data source collection strategy and justification.
- [x] Include descriptive and visual analysis of the data.
- [x] Add relevant screenshots, tables, and evidence.
- [x] Update the README with execution instructions.

### Phase 8: Entrega do Projeto
- [ ] Provide the source code and/or Jupyter notebook on GitHub.
- [ ] Provide CSV files: original treated base, collected complementary base, and final consolidated/enriched base.
- [ ] Deliver the technical report in PDF format.
- [ ] Ensure the README is updated with execution instructions.


