# HP Product Web Scraper

## Descrição

Este projeto implementa um sistema de coleta automatizada de dados de produtos HP em plataformas de e-commerce, desenvolvido como parte do Challenge Sprint - HP. O objetivo é identificar possíveis casos de pirataria de produtos HP, especialmente cartuchos de tinta e toner.

## Funcionalidades

- **Web Scraping Automatizado**: Coleta dados de produtos HP no Mercado Livre
- **Extração Completa de Dados**: Captura título, preço, vendedor, avaliações, descrições e especificações
- **Limpeza de Dados**: Normaliza e estrutura os dados coletados
- **Exportação CSV**: Salva os dados em formato CSV para análises posteriores
- **Logging Detalhado**: Registra todas as operações e erros
- **Tratamento de Erros**: Robustez contra falhas de rede e mudanças no site

## Requisitos

### Dependências Python
```
selenium>=4.0.0
beautifulsoup4>=4.9.0
pandas>=1.3.0
lxml>=4.6.0
```

### Dependências do Sistema
- Google Chrome ou Chromium
- ChromeDriver (gerenciado automaticamente pelo Selenium)

## Instalação

1. **Clone ou baixe o projeto**
```bash
git clone <repository-url>
cd hp-scraper
```

2. **Instale as dependências Python**
```bash
pip install selenium beautifulsoup4 pandas lxml
```

3. **Instale o navegador Chrome/Chromium**
```bash
# Ubuntu/Debian
sudo apt-get install chromium-browser

# CentOS/RHEL
sudo yum install chromium

# macOS
brew install --cask google-chrome
```

## Uso

### Execução Básica
```bash
python hp_scraper.py
```

### Configuração Personalizada
Edite as variáveis no arquivo `hp_scraper.py`:

```python
SEARCH_TERMS = [
    "cartucho hp original",
    "cartucho hp 664 original",
    "cartucho hp 122 original", 
    "toner hp original",
    "cartucho hp compativel"
]

MAX_PAGES = 2  # Número máximo de páginas por termo de busca
```

### Modo Não-Headless (com interface gráfica)
```python
scraper = HPProductScraper(headless=False)
```

## Estrutura dos Dados Coletados

O scraper coleta os seguintes campos para cada produto:

| Campo | Descrição |
|-------|-----------|
| `title` | Título do anúncio |
| `price` | Preço do produto |
| `seller_name` | Nome do vendedor |
| `seller_reputation` | Reputação do vendedor |
| `reviews_count` | Número de avaliações |
| `rating` | Nota do produto |
| `url` | Link do anúncio |
| `platform` | Plataforma de origem |
| `description` | Descrição detalhada |
| `specifications` | Especificações técnicas |
| `images` | URLs das imagens |
| `availability` | Disponibilidade |
| `shipping_info` | Informações de envio |
| `scraped_at` | Data/hora da coleta |

## Arquivos de Saída

- **CSV de Dados**: `hp_products_YYYYMMDD_HHMMSS.csv`
- **Log de Execução**: `hp_scraper.log`

## Estrutura do Código

### Classes Principais

#### `HPProductScraper`
Classe principal que gerencia todo o processo de scraping:

- `setup_driver()`: Configura o WebDriver do Chrome
- `search_mercado_livre()`: Realiza buscas no Mercado Livre
- `extract_product_links()`: Extrai links dos produtos
- `extract_product_details()`: Extrai detalhes de cada produto
- `clean_product_data()`: Limpa e normaliza os dados
- `save_to_csv()`: Salva os dados em CSV

### Funções de Extração

- `safe_extract_text()`: Extração segura de texto
- `extract_price()`: Extração e limpeza de preços
- `extract_seller_reputation()`: Extração de reputação do vendedor
- `extract_reviews_count()`: Extração do número de avaliações
- `extract_rating()`: Extração da nota do produto
- `extract_description()`: Extração da descrição
- `extract_specifications()`: Extração de especificações técnicas
- `extract_images()`: Extração de URLs de imagens

## Tratamento de Erros

O sistema implementa tratamento robusto de erros:

- **Timeouts**: Aguarda carregamento de elementos com timeout configurável
- **Elementos Não Encontrados**: Continua execução mesmo se alguns elementos não existirem
- **Falhas de Rede**: Registra erros e continua com próximos produtos
- **Bloqueios Anti-Scraping**: Implementa delays e user-agents para evitar detecção

## Boas Práticas Implementadas

1. **Delays Respeitosos**: Pausas entre requisições para não sobrecarregar o servidor
2. **User-Agent Realista**: Simula navegador real
3. **Logging Detalhado**: Facilita debugging e monitoramento
4. **Limpeza de Dados**: Normaliza dados para análises consistentes
5. **Estrutura Modular**: Código organizado em funções reutilizáveis

## Limitações e Considerações

- **Rate Limiting**: O scraper implementa delays para evitar bloqueios
- **Mudanças no Site**: Seletores CSS podem precisar de atualização se o site mudar
- **Volume de Dados**: Limitado a evitar sobrecarga dos servidores
- **Aspectos Legais**: Respeita robots.txt e termos de uso das plataformas

## Troubleshooting

### Erro: ChromeDriver não encontrado
```bash
# Instale o Chrome/Chromium
sudo apt-get install chromium-browser
```

### Erro: Timeout ao carregar página
- Verifique sua conexão com a internet
- Aumente o timeout no código se necessário
- Verifique se o site não está bloqueando o acesso

### Erro: Elementos não encontrados
- Os seletores CSS podem ter mudado
- Verifique o log para identificar elementos específicos
- Atualize os seletores conforme necessário

## Contribuição

Para contribuir com o projeto:

1. Faça um fork do repositório
2. Crie uma branch para sua feature
3. Implemente as mudanças
4. Adicione testes se necessário
5. Envie um pull request

## Licença

Este projeto é desenvolvido para fins educacionais como parte do Challenge Sprint - HP.

## Contato

Para dúvidas ou sugestões, entre em contato com a equipe de RPA do Challenge Sprint - HP.

